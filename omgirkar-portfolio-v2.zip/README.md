# Om Girkar - Portfolio

Personal portfolio: https://omgirkar.me

```
index.html, about.html, case-studies.html   main pages
smartnotez.html, avaia.html, guidex.html   project pages
assets/css, assets/js, assets/img, assets/icons
resume.pdf, robots.txt, sitemap.xml
```
